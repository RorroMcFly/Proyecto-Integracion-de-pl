from functools import wraps
from flask import current_app, jsonify
import pyodbc
from flask_jwt_extended import get_jwt_identity

def get_db_connection(connection_string):
    return pyodbc.connect(connection_string)

def get_query_connection():
    connection_string = "Driver={SQL Server};Server='DESKTOP-39MRCJ0\SQLSERVER22';Database='Api';UID=sa;PWD=kira1601;"
    return pyodbc.connect(connection_string, autocommit=True)

def es_administrador(connection_string, username):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    es_admin = cursor.execute("EXEC EsAdministrador @username=?", (username,)).fetchval()
    conn.close()
    return es_admin == 1


def cambiar_rol_usuario(connection_string, username, nuevo_id_rol):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    try:
        cursor.execute("EXEC CambiarRolUsuario @Username=?, @nuevoIDRol=?", (username, nuevo_id_rol))
        conn.commit()
        return True
    except Exception as e:
        print("Error al actualizar el rol:", e)
        conn.rollback()
        return False
    finally:
        conn.close()



def verify_user(connection_string, username, password):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    # Usamos la función HASHBYTES para comparar directamente la contraseña encriptada en la base de datos
    cursor.execute("SELECT 1 FROM Usuario WHERE Username = ? AND Password = HASHBYTES('SHA2_256', CONVERT(VARBINARY, ?))", (username, password))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    # Si result no es None, significa que la combinación de usuario y contraseña es correcta
    return bool(result)


def get_product_info(connection_string):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    cursor.execute("SELECT codigo, marca, nombre, precio, cantidad FROM Producto")
    productos = []
    for row in cursor.fetchall():
        codigo, marca, nombre, precio, cantidad = row
        productos.append({
            "Código del producto": codigo,
            "Marca": marca,
            "Nombre": nombre,
            "Precio": precio,
            "Cantidad": cantidad
        })
    cursor.close()
    conn.close()
    return productos

def actualizar_cantidad_producto(connection_string, codigo, cantidad):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()

    cursor.execute("SELECT Cantidad FROM Producto WHERE Codigo = ?", (codigo,))
    row = cursor.fetchone()
    if row is None:
        conn.close()
        return False
    
    cantidad_actual = row[0]
    nueva_cantidad = cantidad_actual - cantidad

    if nueva_cantidad >= 0:
        cursor.execute("UPDATE Producto SET Cantidad = ? WHERE Codigo = ?", (nueva_cantidad, codigo))
        conn.commit()
        conn.close()
        return True
    else:
        conn.close()
        return False

def obtener_info_producto(connection_string, codigo):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    cursor.execute("SELECT Codigo, Marca, Nombre, Precio, Cantidad FROM Producto WHERE Codigo = ?", (codigo,))
    producto = cursor.fetchone()
    conn.close()
    if producto:
        columns = ["Codigo", "Marca", "Nombre", "Precio", "Cantidad"]
        producto_dict = dict(zip(columns, producto))
        return producto_dict
    else:
        return None

def obtener_id_usuario(connection_string, username):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    cursor.execute("SELECT UserID FROM Usuario WHERE Username = ?", (username,))
    user_id = cursor.fetchone()
    conn.close()
    return user_id[0] if user_id else None

def agregar_producto_al_carrito(connection_string, codigo, cantidad, precio_unitario, username):
    conn = pyodbc.connect(connection_string)
    cursor = conn.cursor()

    id_usuario = obtener_id_usuario(connection_string, username)
    id_producto = obtener_id_producto(connection_string, codigo)

    if id_usuario is None:
        conn.close()
        return jsonify({"msg": "Error: No se encontró el usuario"}), 404
    if id_producto is None:
        conn.close()
        return jsonify({"msg": "Error: No se encontró el producto"}), 404

    try:
        cursor.execute("INSERT INTO Producto_Carrito (UserId, IdProducto, Cantidad, PrecioUnitario, FechaCreacion) VALUES (?, ?, ?, ?, GETDATE())",
                    id_usuario,
                    id_producto,
                    cantidad,
                    precio_unitario)
        conn.commit()
        conn.close()
        return jsonify({"msg": "Producto agregado al carrito exitosamente"}), 200
    except pyodbc.Error as e:
        print("Error al agregar producto al carrito:", e)
        conn.rollback()
        conn.close()
        return jsonify({"msg": "Error al agregar producto al carrito"}), 500
    
def obtener_id_producto(connection_string, codigo):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    cursor.execute("SELECT Id FROM Producto WHERE Codigo = ?", (codigo,))
    producto_id = cursor.fetchone()
    conn.close()
    return producto_id[0] if producto_id else None

def obtener_precio_producto(connection_string, codigo):
    conn = None
    try:
        conn = pyodbc.connect(connection_string)
        cur = conn.cursor()
        cur.execute("SELECT Precio FROM Producto WHERE Codigo = ?", (codigo,))
        precio = cur.fetchone()
        if precio:
            return precio[0]  # Devuelve el precio encontrado
        else:
            return None  # Si no se encuentra el precio, devuelve None
    except pyodbc.Error as e:
        print("Error al obtener el precio del producto:", e)
        return None
    finally:
        if conn:
            conn.close()

def obtener_contenido_carrito(connection_string, username):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    
    UserId = obtener_id_usuario(connection_string, username)
    if UserId:
        cursor.execute("""
            SELECT pc.Id, p.Codigo, p.Marca, p.Nombre, pc.Cantidad, pc.PrecioUnitario
            FROM Producto_Carrito pc
            INNER JOIN Producto p ON pc.IdProducto = p.Id
            WHERE pc.UserID = ?  -- Use el campo correcto que identifica al usuario
        """, (UserId,))
        
        contenido_carrito = []
        for row in cursor.fetchall():
            id_producto, codigo, marca, nombre, cantidad, precio_unitario = row
            contenido_carrito.append({
                "ID Producto": id_producto,
                "Codigo": codigo,
                "Marca": marca,
                "Nombre": nombre,
                "Cantidad": cantidad,
                "Precio unitario": precio_unitario
            })
        
        conn.close()
        return contenido_carrito if contenido_carrito else {"msg": "El carrito está vacío"}
    else:
        conn.close()
        return {"msg": "Usuario no encontrado o carrito vacío"}
    
def obtener_id_carrito(connection_string, user_id):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    
    cursor.execute("SELECT Id FROM Producto_Carrito WHERE UserId = ?", (user_id,))
    id_carrito = cursor.fetchone()
    
    conn.close()
    return id_carrito[0] if id_carrito else None

def obtener_rol_usuario(connection_string, user_id):
    conn = pyodbc.connect(connection_string)
    cursor = conn.cursor()

    # Verificar si el usuario tiene permiso para eliminar productos
    cursor.execute("SELECT IDRol FROM Usuario WHERE UserId = ?", (user_id,))
    row = cursor.fetchone()
    if row is None or row[0] not in [1, 2, 3]:
        conn.close()
        return None  # Usuario no autorizado para eliminar productos

    conn.close()
    return row[0]  # Devuelve el ID de rol del usuario

def eliminar_producto_inventario(connection_string, codigo_producto, usuario_id):
    conn = get_db_connection(connection_string)
    cursor = conn.cursor()
    try:
        # Primero, verificar si el usuario es administrador
        cursor.execute("SELECT RolId FROM Usuario WHERE UsuarioId = ?", (usuario_id,))
        rol_id = cursor.fetchone()
        if rol_id is None or rol_id[0] != 1:  # Suponiendo que 1 es el ID para administradores
            return False, "Usuario no autorizado"

        # Ejecutar la eliminación si el usuario es administrador y el producto no está en uso
        cursor.execute("DELETE FROM Producto WHERE Codigo = ? AND NOT EXISTS (SELECT 1 FROM DetallesFactura WHERE ProductoId = Producto.ProductoId) AND NOT EXISTS (SELECT 1 FROM Carrito WHERE ProductoId = Producto.ProductoId)", (codigo_producto,))
        conn.commit()
        return True, "Producto eliminado exitosamente"
    except Exception as e:
        print("Error al eliminar producto:", e)
        conn.rollback()
        return False, "Error al eliminar producto"
    finally:conn.close()
        
def obtener_user_id_por_username(connection_string, username):
    conn = pyodbc.connect(connection_string)
    cursor = conn.cursor()
    user_id = None
    
    try:
        cursor.execute("SELECT UserId FROM Usuario WHERE Username = ?", username)
        row = cursor.fetchone()
        if row:
            user_id = row[0]
            print(f"ID de usuario encontrado: {user_id}")  # Agrega esta línea para ver el ID de usuario en la consola
    except Exception as e:
        print(f"Error al obtener el ID de usuario por nombre de usuario: {e}")
    finally:
        conn.close()
    
    return user_id


def crear_producto(codigo, marca, nombre, precio, cantidad):
    conn = get_db_connection(current_app.config['CONNECTION_STRING'])
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO Producto (Codigo, Marca, Nombre, Precio, Cantidad) VALUES (?, ?, ?, ?, ?)",
                    (codigo, marca, nombre, precio, cantidad))
        conn.commit()
        return jsonify({"msg": "Producto creado exitosamente"}), 200
    except Exception as e:
        print("Error al crear el producto:", e)
        conn.rollback()
        return jsonify({"msg": "Error al crear el producto"}), 500
    finally:
        conn.close()
        
def modificar_producto(codigo, nueva_marca, nuevo_nombre, nuevo_precio, nueva_cantidad):
    conn = get_db_connection(current_app.config['CONNECTION_STRING'])
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE Producto SET Marca = ?, Nombre = ?, Precio = ?, Cantidad = ? WHERE Codigo = ?",
                    (nueva_marca, nuevo_nombre, nuevo_precio, nueva_cantidad, codigo))
        conn.commit()
        return jsonify({"msg": "Producto modificado exitosamente"}), 200
    except Exception as e:
        print("Error al modificar el producto:", e)
        conn.rollback()
        return jsonify({"msg": "Error al modificar el producto"}), 500
    finally:
        conn.close()
        
def eliminar_producto(codigo):
    conn = get_db_connection(current_app.config['CONNECTION_STRING'])
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM Producto WHERE Codigo = ?", (codigo,))
        conn.commit()
        return jsonify({"msg": "Producto eliminado exitosamente"}), 200
    except Exception as e:
        print("Error al eliminar el producto:", e)
        conn.rollback()
        return jsonify({"msg": "Error al eliminar el producto"}), 500
    finally:
        conn.close()